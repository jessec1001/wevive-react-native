# Notifications

A small collection of hand-crafted, subtle notification tones for mobile devices.

# License

Dual license -- choose between these two.

* [CC Attribution 3.0 Unported](http://creativecommons.org/licenses/by/3.0/)
* [CC0 Public Domain](http://creativecommons.org/publicdomain/mark/1.0/)

My intention is that it would be _nice_ to get some sort of attribution if you create
derivative works or repackage some of the sounds or whatnot, but it's by no means necessary.
